const fs = require('fs');
const { reply, getSender, getIsOwner } = require('./_helper');
const FILE = './data/antidelete.json';
function get() { try { return JSON.parse(fs.readFileSync(FILE,'utf8')); } catch { return {enabled:false}; } }
function save(d) { fs.writeFileSync(FILE, JSON.stringify(d,null,2)); }
function isEnabled() { return get().enabled === true; }

const handler = async (sock, chatId, message, args) => {
    const sender = getSender(sock, message);
    if (!await getIsOwner(sock)(sender, sock, chatId)) return reply(sock, chatId, '❌ Owner only.', message);
    const d = get(), sub = args[0]?.toLowerCase();
    if (!sub) return reply(sock, chatId, `🗑️ *Anti-Delete*\nStatus: ${d.enabled?'✅ ON':'❌ OFF'}\n\n.antidelete on\n.antidelete off\n\n_Notifies you when someone deletes a message_`, message);
    if (sub==='on')  { save({enabled:true});  return reply(sock, chatId, '✅ Anti-delete enabled!', message); }
    if (sub==='off') { save({enabled:false}); return reply(sock, chatId, '❌ Anti-delete disabled.', message); }
};

handler.isEnabled = isEnabled;
module.exports = handler;
module.exports.isEnabled = isEnabled;
